<?php $__env->startSection('content'); ?>
<section class="counts section-bg">
    <div class="container">
  
      <div class="section-title">
        <h2>Berita Desa</h2>
      </div>
  
      <div class="row">
        <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 mb-3" data-aos="fade-up">
                <div class="count-box news-card">
                    <div class="card">
                        <img src="<?php echo e(asset('storage/' . $berita->gambar)); ?>" alt="Gambar Berita" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($berita->judul); ?></h5>
                            <div class="news-date"><?php echo e($berita->created_at->diffForHumans()); ?></div>
                            <p class="card-text"><?php echo e($berita->excerpt); ?></p>                           
                        </div>
                        <div class="card-footer">
                            <a href="/berita/<?php echo e($berita->slug); ?>" type="button" class="btn btn-link float-end">Selengkapnya</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <?php echo e($beritas->links()); ?>


    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/berita/index.blade.php ENDPATH**/ ?>