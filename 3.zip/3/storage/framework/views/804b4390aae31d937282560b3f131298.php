<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 d-flex align-items-strech">
      <div class="card w-100">
        <div class="card-header bg-primary">
            <div class="row align-items-center">
                <div class="col-6">
                    <h5 class="card-title fw-semibold text-white">Visi & Misi Desa</h5>
                </div>
                <div class="col-6 text-right">
                    <a href="/visi-misi" type="button" class="btn btn-warning float-end" target="_blank">Live Preview</a>
                </div>
            </div>
        </div>
        
        <div class="card-body">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col p-5">
                    <div class="col p-5">
                        <h5>Visi & Misi Desa</h5>
                        <div class="visi-misi">
                            <div class="visi mb-3">
                                <p class="fw-bolder">Visi</p>
                                <p><?php echo $visiMisi->visi; ?></p>
                            </div>
                            <div class="misi mb-3">
                                <p class="fw-bolder">Misi</p>
                                <p><?php echo $visiMisi->misi; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <a href="/admin/visi-misi/<?php echo e($visiMisi->id); ?>/edit" type="button" class="btn btn-warning mb-1 float-end"><i class="ti ti-edit"></i> Edit Visi & Misi</a>
        </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa\resources\views/admin/visi-misi/index.blade.php ENDPATH**/ ?>