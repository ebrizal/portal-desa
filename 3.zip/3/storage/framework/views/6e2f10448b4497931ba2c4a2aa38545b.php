<?php $__env->startSection('content'); ?>
    <section class="counts section-bg">
        <div class="section-title">
            <h2>Gallery</h2>
        </div>
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $galerrys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3">
                        <picture>
                            <img src="<?php echo e(asset('storage/' . $gallery->gambar)); ?>" class="img-fluid img-thumbnail"
                                alt="Gallery" style="width: 300px; height: 200px; object-fit: cover;">
                            <p><?php echo e($gallery->keterangan); ?></p>
                        </picture>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="paginate my-3" style="text-align: center">
                <?php echo e($galerrys->links()); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/gallery/index.blade.php ENDPATH**/ ?>