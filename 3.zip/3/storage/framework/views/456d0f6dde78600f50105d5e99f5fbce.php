<?php $__env->startSection('content'); ?>
    <section class="counts section-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 mx-auto">
                    <div class="row">
                        <div class="col-md-12 mb-5">
                            <div class="card p-3">
                                <div class="card-body">
                                    <p><a href="/pengumuman">Pengumuman</a> >> <a
                                            href="<?php echo e($pengumuman->slug); ?>"><?php echo e($pengumuman->judul); ?></a></p>

                                    <h1 class="mb-3"><?php echo e($pengumuman->judul); ?></h1>

                                    <div class="news-date mb-4">
                                        <span class="mr-3"> <i class="bi bi-stopwatch-fill"></i>
                                            <?php echo e($pengumuman->created_at->diffForHumans()); ?></span> |
                                        <span class="mr-3"><i class="bi bi-person-circle">
                                                <?php echo e($pengumuman->user->name); ?></i></span> |
                                        <span><i class="bi bi-fire">Dibaca <?php echo e($pengumuman->views); ?> Kali</i></span>
                                    </div>

                                    <p><?php echo $pengumuman->isi_pengumuman; ?></p>

                                </div>
                            </div>
                        </div>


                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/pengumuman/detail.blade.php ENDPATH**/ ?>