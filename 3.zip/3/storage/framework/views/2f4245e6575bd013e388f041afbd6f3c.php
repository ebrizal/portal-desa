<?php $__env->startSection('content'); ?>
<section class="counts section-bg">
    <div class="container">
        <div class="section-title">
            <h2>Detail Produk</h2>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="row p-4">
                        <div class="col-lg-4">
                            <img src="<?php echo e(asset('storage/' . $umkm->foto)); ?>" alt="Gambar produk" class="img-fluid">
                        </div>
                        <div class="col-lg-8">
                            <div class="card-body">
                                <h2 class="card-title"><b><?php echo e($umkm->produk); ?></b></h2>
                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <td>Harga</td>
                                            <td>:</td>
                                            <td>Rp. <?php echo e(number_format($umkm->harga, 0, ',', '.')); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Deskripsi</td>
                                            <td>:</td>
                                            <td><?php echo $umkm->deskripsi; ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                
                                <a href="https://wa.me/+62<?php echo e($umkm->no_hp); ?>" class="btn btn-success mt-3" role="button"><i class="bi bi-whatsapp"></i> Hubungi Penjual</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/umkm/detail.blade.php ENDPATH**/ ?>