<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 d-flex align-items-strech">
            <div class="card w-100">
                <div class="card-header bg-primary">
                    <div class="row align-items-center">
                        <div class="col-6">
                            <h5 class="card-title fw-semibold text-white">Gallery</h5>
                        </div>
                        <div class="col-6 text-right">
                            <a href="/admin/gallery/create" type="button" class="btn btn-warning float-end">Tambah
                                Gallery</a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="table-responsive">
                            <table id="table_id" class="table display">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Gambar</th>
                                        <th>Keterangan</th>
                                        <th>Opsi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $gallerys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><img src="<?php echo e(asset('storage/' . $gallery->gambar)); ?>" alt="Foto Gallery"
                                                    class="img-fluid" style="max-height: 200px; max-width: 200px"></td>
                                            <td><?php echo e($gallery->keterangan); ?></td>
                                            <td>
                                                <a href="/admin/gallery/<?php echo e($gallery->id); ?>/edit" type="button"
                                                    class="btn btn-warning mb-1"><i class="ti ti-edit"></i></a>
                                                <form id="<?php echo e($gallery->id); ?>" action="/admin/gallery/<?php echo e($gallery->id); ?>"
                                                    method="POST" class="d-inline">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button type="button" class="btn btn-danger swal-confirm mb-1"
                                                        data-form="<?php echo e($gallery->id); ?>"><i class="ti ti-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#table_id').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/admin/gallery/index.blade.php ENDPATH**/ ?>