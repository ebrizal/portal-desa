<?php $__env->startSection('content'); ?>
<section class="counts section-bg">
    <div class="container">
  
      <div class="section-title">
        <h2><?php echo e($petaDesa->judul); ?></h2>
      </div>
  
      <div class="row">
        <div class="col-lg-10 mx-auto p-3">
            <iframe width="100%" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" id="gmap_canvas" src="https://maps.google.com/maps?width=520&amp;height=400&amp;hl=en&amp;q=<?php echo e(urlencode($petaDesa->alamat)); ?>&amp;t=h&amp;z=13&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/peta-desa/index.blade.php ENDPATH**/ ?>