<?php $__env->startSection('content'); ?>
<style>
    .custom-card {
        width: 100%;
        height: 375px; /* Atur tinggi kartu sesuai kebutuhan */
    }

    .card-img {
        width: 100%;
        height: 100%;
        border-radius: 5px;
        background-size: cover; /* Untuk mengisi kartu dengan gambar tanpa pemotongan */
    }
</style>
  
<div class="row">
    <div class="col-lg-12 d-flex align-items-strech">
      <div class="card w-100">
        <div class="card-header bg-primary">
            <div class="row align-items-center">
                <div class="col-6">
                    <h5 class="card-title fw-semibold text-white">Gambar Slider</h5>
                </div>
                <div class="col-6 text-right">
                    <a href="/" type="button" class="btn btn-warning float-end" target="_blank">Live Preview</a>
                </div>
            </div>
        </div>
        
        <div class="card-body">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="row">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card custom-card mb-4">
                        <div class="card-img" style="background-image: url('<?php echo e(asset('storage/' . $slider->img_slider)); ?>');"></div>
                        <div class="card-body">
                            <p>Slider <?php echo e($loop->iteration); ?></p>
                            <h5 class="card-title"><?php echo e($slider->judul); ?></h5>
                            <a href="/admin/slider/<?php echo e($slider->id); ?>/edit" type="button" class="btn btn-warning">Edit</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/admin/slider/index.blade.php ENDPATH**/ ?>