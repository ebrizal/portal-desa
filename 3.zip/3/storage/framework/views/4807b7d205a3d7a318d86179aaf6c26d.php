<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 d-flex align-items-strech">
      <div class="card w-100">
        <div class="card-header bg-primary">
            <div class="row align-items-center">
                <div class="col-6">
                    <h5 class="card-title fw-semibold text-white">Gambar Slider</h5>
                </div>
                <div class="col-6 text-right">
                    <a href="/wilayah" type="button" class="btn btn-warning float-end" target="_blank">Live Preview</a>
                </div>
            </div>
        </div>
        
        <div class="card-body">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col p-5">
                    <h5><?php echo e($wilayah->judul); ?></h5>
                    <p>
                        <?php echo $wilayah->body; ?>

                    </p>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <a href="/admin/wilayah/<?php echo e($wilayah->id); ?>/edit" type="button" class="btn btn-warning mb-1 float-end"><i class="ti ti-edit"></i> Edit Sejarah</a>
        </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa\resources\views/admin/wilayah/index.blade.php ENDPATH**/ ?>