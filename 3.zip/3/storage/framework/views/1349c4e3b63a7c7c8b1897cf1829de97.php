<?php $__env->startSection('content'); ?>
<section class="counts section-bg">
    <div class="container">
        <div class="section-title">
            <h2>UMKM Desa</h2>
        </div>
        <div class="row">
            <?php $__currentLoopData = $umkms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $umkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 mb-3" data-aos="fade-up">
                <div class="count-box news-card">
                    <div class="card">
                        <img src="<?php echo e(asset('storage/' . $umkm->foto)); ?>" alt="Foto UMKM" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title"><b><?php echo e($umkm->produk); ?></b></h5>
                            <p class="card-text"><i class="bi bi-tag"></i>&nbsp; Rp <?php echo e(number_format($umkm->harga, 0, ',', '.')); ?></p>
                        </div>
                        <a class="btn btn-success mx-3 my-1" href="https://wa.me/+62<?php echo e($umkm->no_hp); ?>" role="button"><i class="bi bi-whatsapp"></i>&nbsp; Hubungi Penjual</a>
                        <a class="btn btn-warning mx-3 mb-3" href="/umkm/<?php echo e($umkm->slug); ?>" role="button"><i class="bi bi-eye"></i>&nbsp; Detail Produk</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="paginate my-3" style="text-align: center">
            <?php echo e($umkms->links()); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/umkm/index.blade.php ENDPATH**/ ?>