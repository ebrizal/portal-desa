<?php $__env->startSection('content'); ?>
    <section class="counts section-bg">
        <div class="section-title">
            <h2>Layanan</h2>
        </div>
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $layanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4">
                        <div class="accordion" id="accordionExample<?php echo e($layanan->id); ?>">
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse<?php echo e($layanan->id); ?>" aria-expanded="true"
                                        aria-controls="collapse<?php echo e($layanan->id); ?>">
                                        <?php echo e($layanan->layanan); ?>

                                    </button>
                                </h2>
                                <div id="collapse<?php echo e($layanan->id); ?>" class="accordion-collapse collapse show"
                                    data-bs-parent="#accordionExample<?php echo e($layanan->id); ?>">
                                    <div class="accordion-body">
                                        <?php echo $layanan->persyaratan; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/layanan/index.blade.php ENDPATH**/ ?>