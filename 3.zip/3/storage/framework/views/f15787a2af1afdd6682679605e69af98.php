<?php $__env->startSection('content'); ?>

  
<div class="row">
    <div class="col-lg-12 d-flex align-items-strech">
      <div class="card w-100">
        <div class="card-header bg-primary">
            <div class="row align-items-center">
                <div class="col-6">
                    <h5 class="card-title fw-semibold text-white">Perangkat Desa</h5>
                </div>
                <div class="col-6 text-right">
                    <a href="/perangkat-desa" type="button" class="btn btn-warning float-end me-2" target="_blank">Live Preview</a>
                </div>
            </div>
        </div>
        
        <div class="card-body">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="row">
                <div class="button">
                    <a href="/admin/perangkat-desa/create" type="button" class="btn btn-success my-3">Tambah Perangkat Desa</a>
                </div>

                <?php $__currentLoopData = $perangkatDesas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perangkat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-xl-3 my-3" data-aos="fade-up">
                    <div class="member">
                      <div class="pic"><img src="<?php echo e(asset('storage/' . $perangkat->foto)); ?>" class="img-fluid" alt="" style="border-radius: 5px"></div>
                      <div class="member-info my-2">
                        <h4 class="text-center"><?php echo e($perangkat->nama); ?></h4>
                        <p class="text-center"><?php echo e($perangkat->jabatan); ?></p>
                        <div class="text-center"> 
                          <a href="/admin/perangkat-desa/<?php echo e($perangkat->id); ?>/edit" type="button" class="btn btn-warning">Edit Data</a>
                          <form id="<?php echo e($perangkat->id); ?>" action="/admin/perangkat-desa/<?php echo e($perangkat->id); ?>" method="POST" class="d-inline">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="button" class="btn btn-danger swal-confirm" data-form="<?php echo e($perangkat->id); ?>">Hapus</button>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              
        </div>

      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/admin/perangkat-desa/index.blade.php ENDPATH**/ ?>