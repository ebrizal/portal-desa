<?php $__env->startSection('content'); ?>
<section class="counts section-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-md-12 mb-5">
                        <div class="card">
                            <div class="card-body">
                                <p>Berita >> <a href="<?php echo e($berita->slug); ?>"><?php echo e($berita->judul); ?></a></p>
                                <h1><?php echo e($berita->judul); ?></h1>

                                <div class="news-date mb-4">
                                    <span class="mr-3"> <i class="bi bi-stopwatch-fill"></i> <?php echo e($berita->created_at->diffForHumans()); ?></span> |
                                    <span class="mr-3"><i class="bi bi-person-circle"> <?php echo e($berita->user->name); ?></i></span> |
                                    <span><i class="bi bi-fire">Dibaca <?php echo e($berita->views); ?> Kali</i></span>
                                </div>

                                <img src="<?php echo e(asset('storage/' . $berita->gambar)); ?>" alt="Gambar Andalan" class="img-fluid rounded mb-5" style="height: 450px; width: 100%;">
                                <p><?php echo $berita->body; ?></p>

                                <i class="bi bi-tags"></i> <a href="#" type="button" class="btn btn-secondary btn-sm my-2"><?php echo e($berita->kategori->kategori); ?></a>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-md-12 mb-5">
                        <div class="card">
                            <div class="container mb-3">
                                <div class="row d-flex justify-content-center">
                                    <div class="col-md-12">
                                        <div class="card-body">
                                            <h4 class="mt-3 mb-5">Komentar</h4>

                                            <?php $__currentLoopData = $berita->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $emailHash = md5(strtolower(trim($comment->email)));
                                                    $avatarUrl = "https://www.gravatar.com/avatar/{$emailHash}?s=65";
                                                ?>

                                                <div class="comment-container mb-4 d-flex align-items-start">
                                                    <div class="comment-avatar me-3">
                                                        <img class="rounded-circle shadow-1-strong" src="<?php echo e($avatarUrl); ?>" alt="Avatar" width="65" height="65">
                                                    </div>
                                                    <div class="comment-content flex-grow-1">
                                                        <div class="comment-header d-flex justify-content-between align-items-center">
                                                            <h5><?php echo e($comment->nama); ?></h5>
                                                            <a href="javascript:void(0)" onclick="toggleReplyForm(<?php echo e($comment->id); ?>)" class="reply"><i class="bi bi-reply-fill"></i> Balas</a>
                                                        </div>
                                                        <time datetime="2020-01-01"> <?php echo e($comment->created_at->diffForHumans()); ?></time>
                                                        <p class="mt-2"><?php echo e($comment->body); ?></p>
                                                    </div>
                                                </div>

                                                <!-- Comment Reply -->
                                                <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $replyEmailHash = md5(strtolower(trim($reply->email)));
                                                        $replyAvatarUrl = "https://www.gravatar.com/avatar/{$replyEmailHash}?s=65";
                                                    ?>
                                                    <div class="comment-container my-4 ms-5 d-flex align-items-start">
                                                        <div class="comment-avatar me-3">
                                                            <img class="rounded-circle shadow-1-strong" src="<?php echo e($replyAvatarUrl); ?>" alt="Avatar" width="65" height="65">
                                                        </div>
                                                        <div class="comment-content flex-grow-1">
                                                            <div class="comment-header d-flex justify-content-between align-items-center">
                                                                <h5><?php echo e($reply->nama); ?></h5>
                                                            </div>
                                                            <time datetime="2020-01-01"><?php echo e(\Carbon\Carbon::parse($reply->created_at)->diffForHumans()); ?></time>
                                                            <p class="mt-2"><?php echo e($reply->body); ?></p>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <!-- Comment Reply Form -->
                                                <div id="replyForm<?php echo e($comment->id); ?>" class="reply-form mb-3" style="display: none;">
                                                    <form action="/berita/<?php echo e($berita->slug); ?>/reply" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" value="<?php echo e($comment->id); ?>" name="comment_id">
                                                        <div class="mb-3">
                                                            <input type="text" class="form-control" placeholder="Nama" name="replyNama">
                                                        </div>
                                                        <div class="mb-3">
                                                            <input type="email" class="form-control" placeholder="Email" name="replyEmail">
                                                        </div>
                                                        <div class="mb-3">
                                                            <textarea class="form-control" placeholder="Balasan Komentar" name="replyBody" rows="3"></textarea>
                                                        </div>
                                                        <input type="hidden" name="parent_id" value="<?php echo e($comment->id); ?>">
                                                        <button type="submit" class="btn btn-primary btn-sm">Kirim Balasan</button>
                                                    </form>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                            </div>
                            <div class="card-body">
                                <h5 class="mb-4">Tinggalkan Komentar : </h5>
                                <form method="POST" action="/berita/<?php echo e($berita->slug); ?>">
                                    <?php echo csrf_field(); ?>

                                    <div class="mb-3">
                                        <label for="nama" class="form-label">Nama</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama" name="nama">
                                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email</label>
                                        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="body" class="form-label">Komentar</label>
                                        <textarea class="form-control <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="body" name="body" rows="6"></textarea>
                                        <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <button type="submit" class="btn btn-primary float-end">Kirim Komentar</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="sidebar">
                    <div class="card">
                        <div class="card-body">
                            <h4>Berita Populer</h4>
                            <div class="populer-post mb-5">
                                <?php $__currentLoopData = $beritaPopuler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row mt-3">
                                        <div class="col-md-5">
                                            <img src="<?php echo e(asset('storage/' . $berita->gambar)); ?>" width="100%" height="100%" style="border-radius: 5px">
                                        </div>
                                        <div class="col-md-7 mt-2">
                                            <a href="/berita/<?php echo e($berita->slug); ?>" style="color: inherit;"><h6><?php echo e($berita->judul); ?></h6></a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>

                    <div class="card my-3">
                        <div class="card-body">
                            <h4>Kategori</h4>
                            <div class="populer-post mb-5">
                                <div class="row mt-3">
                                    <div class="col">
                                        <?php $__currentLoopData = $kategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <ul>
                                                <p><i class="bi bi-hash"></i> <a href="/kategori/<?php echo e($kategori->slug); ?>" style="color: inherit;"><?php echo e($kategori->kategori); ?></a></p>
                                            </ul>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<script>
    function toggleReplyForm(commentId) {
        var replyForm = document.getElementById('replyForm' + commentId);
        var formDisplayStyle = window.getComputedStyle(replyForm).getPropertyValue('display');
        if (formDisplayStyle === 'none') {
            replyForm.style.display = 'block';
        } else {
            replyForm.style.display = 'none';
        }
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/berita/detail.blade.php ENDPATH**/ ?>