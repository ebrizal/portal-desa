<?php $__env->startSection('content'); ?>
    <section class="counts section-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 mx-auto">
                    <div class="row">
                        <div class="col-md-12 mb-5">
                            <div class="card p-3">
                                <div class="card-body">
                                    <p><a href="/apbdesa">Anggaran</a> >> <a
                                            href="<?php echo e($anggaran->slug); ?>"><?php echo e($anggaran->judul); ?></a></p>

                                    <h1 class="mb-3"><?php echo e($anggaran->judul); ?></h1>

                                    <div class="news-date mb-4">
                                        <span class="mr-3"><i class="bi bi-person-circle">
                                                Diposting oleh : <?php echo e($anggaran->user->name); ?></i></span>
                                    </div>

                                    <img src="<?php echo e(asset('storage/' . $anggaran->gambar)); ?>" alt="Gambar Andalan"
                                        class="img-fluid rounded mb-5" style="height: 450px; width: 100%;">

                                    <p><?php echo $anggaran->keterangan; ?></p>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/apbdesa/detail.blade.php ENDPATH**/ ?>